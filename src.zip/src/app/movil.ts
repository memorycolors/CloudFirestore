export interface Movil {
    titulo:String;
    descripcion: String;
    precio: Number;
    fechasalida:String;
    imagenes:String;
}
